module Rails::InfoHelper
end
