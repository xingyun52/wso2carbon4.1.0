require 'test_helper'

class <%= controller_class_name %>HelperTest < ActionView::TestCase
end
