require 'arjdbc/jdbc'
require 'arjdbc/sybase/adapter.rb'
