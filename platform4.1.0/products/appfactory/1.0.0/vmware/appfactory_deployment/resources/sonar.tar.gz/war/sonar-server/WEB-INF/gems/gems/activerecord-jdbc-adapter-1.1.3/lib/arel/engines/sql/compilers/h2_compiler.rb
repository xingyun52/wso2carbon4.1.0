module Arel
  module SqlCompiler
    class H2Compiler < GenericCompiler
    end
  end
end
