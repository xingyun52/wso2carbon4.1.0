require "#{RAILS_ROOT}/config/environment"
require 'rails/info'
puts Rails::Info
