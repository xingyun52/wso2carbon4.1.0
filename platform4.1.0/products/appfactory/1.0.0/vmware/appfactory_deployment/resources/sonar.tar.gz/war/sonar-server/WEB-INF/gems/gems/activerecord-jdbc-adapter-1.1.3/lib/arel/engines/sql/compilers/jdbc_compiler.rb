module Arel
  module SqlCompiler
    class JDBCCompiler < GenericCompiler
    end
  end
end
