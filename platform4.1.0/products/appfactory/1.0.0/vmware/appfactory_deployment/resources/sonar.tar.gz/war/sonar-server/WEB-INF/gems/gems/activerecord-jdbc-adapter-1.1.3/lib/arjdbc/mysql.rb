require 'arjdbc/jdbc'
jdbc_require_driver 'jdbc/mysql'
require 'arjdbc/mysql/connection_methods'
require 'arjdbc/mysql/adapter'
