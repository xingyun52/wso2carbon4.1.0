require 'arjdbc/jdbc'
jdbc_require_driver 'jdbc/postgres'
require 'arjdbc/postgresql/connection_methods'
require 'arjdbc/postgresql/adapter'
