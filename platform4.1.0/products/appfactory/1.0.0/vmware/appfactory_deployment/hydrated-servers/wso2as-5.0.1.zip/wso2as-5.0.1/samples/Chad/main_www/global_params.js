/*This is just an empty js which has put their to support all the containers.
The content of the js has been pumped by org.wso2.adminui.AdminUIServletFilter filter.
*/
