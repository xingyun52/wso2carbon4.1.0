source ./CreateTables.sql
source ./Category.sql
source ./Product.sql

